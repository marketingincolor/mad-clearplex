<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "off-canvas-wrap" div and all content after.
 *
 * @package FoundationPress
 * @since FoundationPress 1.0.0
 */

?>

		</section>

		<div class="footer-container" data-sticky-footer>
			<footer class="footer">
				<div class="row">
					<div class="large-4 columns">
						
					</div>
					<div class="large-4 large-offset-2 columns">
						
					</div>
					<div class="large-2 columns">
						
					</div>
				</div>
			</footer>
		</div>

<?php wp_footer(); ?>

</body>
</html>
